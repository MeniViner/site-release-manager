async function request(path, options = {}) {
  const response = await fetch(path, options);
  const contentType = response.headers.get('content-type') || '';
  const payload = contentType.includes('application/json') ? await response.json() : null;
  if (!response.ok) {
    const error = new Error(payload?.error || `HTTP ${response.status}`);
    error.status = response.status;
    error.payload = payload;
    throw error;
  }
  return payload;
}

export const api = {
  config: () => request('/api/config'),
  dashboard: () => request('/api/dashboard'),
  sites: () => request('/api/sites'),
  createSite: (body) => request('/api/sites', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
  updateSite: (id, body) => request(`/api/sites/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
  deleteSite: (id) => request(`/api/sites/${id}`, { method: 'DELETE' }),
  deploy: (siteId, releaseId, { force = false } = {}) => request(`/api/sites/${siteId}/deploy`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ releaseId, force }) }),
  releases: () => request('/api/releases'),
  releaseVersionSuggestions: () => request('/api/releases/version-suggestions'),
  uploadRelease: (formData) => request('/api/releases/upload', { method: 'POST', body: formData }),
  uploadReleaseFolder: (formData) => request('/api/releases/upload-folder', { method: 'POST', body: formData }),
  updateRelease: (id, body) => request(`/api/releases/${id}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }),
  deleteRelease: (id) => request(`/api/releases/${id}`, { method: 'DELETE' }),
  job: (id) => request(`/api/jobs/${id}`),
  verifyLocalDeployment: (id) => request(`/api/deployments/${id}/verify-local`, { method: 'POST' }),
  runs: () => request('/api/runs?limit=100'),
  run: (id) => request(`/api/runs/${id}`),
};
