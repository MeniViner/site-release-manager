import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const steps = [];
let failed = false;

function run(label, command, args, options = {}) {
  console.log(`\n=== ${label} ===`);
  const result = spawnSync(command, args, {
    cwd: options.cwd || root,
    stdio: 'inherit',
    shell: false,
    env: process.env,
  });
  const ok = !result.error && result.status === 0;
  steps.push({ label, ok, status: result.status, error: result.error?.message || '' });
  if (!ok) failed = true;
  return ok;
}

const required = [
  'scripts/dev.mjs',
  'scripts/doctor.mjs',
  'server/src/index.js',
  'server/src/routes/sites.js',
  'server/src/routes/releases.js',
  'server/src/services/jobQueue.js',
  'server/src/services/deploymentService.js',
  'server/src/services/runTelemetry.js',
  'server/src/routes/runs.js',
  'server/src/utils/versioning.js',
  'client/src/App.jsx',
  'client/src/RunsPage.jsx',
  'client/src/api.js',
  'sharepoint-deployer/ready/app.js',
];

console.log('=== Site Release Manager verify:system ===');
for (const rel of required) {
  const ok = fs.existsSync(path.join(root, rel));
  console.log(`${ok ? 'PASS' : 'FAIL'} file ${rel}`);
  if (!ok) failed = true;
}

run('Doctor: source, dependencies and MongoDB', process.execPath, ['scripts/doctor.mjs']);
run('Server tests', 'npm', ['--prefix', 'server', 'test']);
run('Client production build', 'npm', ['--prefix', 'client', 'run', 'build']);
run('SharePoint deployer build', 'npm', ['--prefix', 'sharepoint-deployer', 'run', 'build']);

for (const rel of [
  'server/src/routes/sites.js',
  'server/src/routes/releases.js',
  'server/src/services/jobQueue.js',
  'server/src/services/deploymentService.js',
  'server/src/services/runTelemetry.js',
  'server/src/routes/runs.js',
  'server/src/utils/versioning.js',
  'scripts/dev.mjs',
  'scripts/doctor.mjs',
  'scripts/mongo.mjs',
]) {
  run(`Syntax ${rel}`, process.execPath, ['--check', rel]);
}

console.log('\n=== SUMMARY ===');
for (const step of steps) console.log(`${step.ok ? 'PASS' : 'FAIL'} ${step.label}`);
console.log(failed ? '\nVERIFY SYSTEM FAILED' : '\nVERIFY SYSTEM PASSED');
process.exit(failed ? 1 : 0);
