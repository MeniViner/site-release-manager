import { spawnSync } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const folders = ['client', 'server', 'sharepoint-deployer'];

for (const folder of folders) {
  console.log(`\n[install] ${folder}`);
  const result = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install'], {
    cwd: path.join(root, folder),
    stdio: 'inherit',
  });
  if (result.status !== 0) process.exit(result.status ?? 1);
}

console.log('\nAll project dependencies were installed.');
