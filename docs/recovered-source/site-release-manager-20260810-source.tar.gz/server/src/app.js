import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import cors from 'cors';
import multer from 'multer';
import { config, rootDir } from './config.js';
import { dashboardRouter } from './routes/dashboard.js';
import { sitesRouter } from './routes/sites.js';
import { releasesRouter } from './routes/releases.js';
import { jobsRouter } from './routes/jobs.js';
import { deploymentsRouter } from './routes/deployments.js';
import { runsRouter } from './routes/runs.js';

export function createApp() {
  const app = express();
  const allowedOrigins = new Set([
    config.clientOrigin,
    ...config.sharePointHosts.map((host) => `https://${host}`),
  ]);

  app.use(cors({
    origin(origin, callback) {
      if (!origin || allowedOrigins.has(origin)) return callback(null, true);
      return callback(new Error(`Origin is not configured: ${origin}`));
    },
    credentials: false,
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Accept'],
  }));
  app.use(express.json({ limit: '2mb' }));

  app.get('/api/health', (_req, res) => res.json({ ok: true }));
  app.get('/api/config', (_req, res) => res.json({
    sharePointHosts: config.sharePointHosts,
    sharePointDeployerPath: config.sharePointDeployerPath,
    storageType: 'txt',
  }));
  app.use('/api/dashboard', dashboardRouter);
  app.use('/api/sites', sitesRouter);
  app.use('/api/releases', releasesRouter);
  app.use('/api/jobs', jobsRouter);
  app.use('/api/deployments', deploymentsRouter);
  app.use('/api/runs', runsRouter);

  const clientDist = path.join(rootDir, 'client', 'dist');
  if (fs.existsSync(clientDist)) {
    app.use(express.static(clientDist));
    app.get(/^(?!\/api\/).*/, (_req, res) => res.sendFile(path.join(clientDist, 'index.html')));
  }

  app.use((error, _req, res, _next) => {
    console.error(error);
    if (error instanceof multer.MulterError) {
      return res.status(400).json({ error: error.code === 'LIMIT_FILE_SIZE' ? 'קובץ בריליס גדול מהמגבלה.' : error.code === 'LIMIT_FILE_COUNT' ? 'התיקייה מכילה יותר מדי קבצים.' : error.message });
    }
    if (Number.isInteger(error?.statusCode)) {
      return res.status(error.statusCode).json({ error: error.message || 'הקלט אינו תקין.' });
    }
    return res.status(500).json({ error: error.message || 'שגיאת שרת.' });
  });

  return app;
}
